$(document).ready(function(){
  $("#loginbtn").click(function(){
   var email=$("#email").val();
   var pass=$("#pass").val();
   
   $.post("login",{email:email,pass:pass,},function(result){
	   location.href = result;
   });
   
  });
});