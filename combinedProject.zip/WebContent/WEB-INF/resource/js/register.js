$(document).ready(function(){
  $("#rgbtn").click(function(){
   
   var email=$("#email").val();
   var pass=$("#pass").val();
   
   
  
   if(email==""){
	   alert("please enter email");
	   $("#email").focus().css("border-color","red");
   }else if(pass==""){
	   alert("please enter password");
	   $("#pass").focus().css("border-color","red");
   }
   else{ 
  
   $.post("insert",{email:email,pass:pass,},function(result){
	   location.href = result;
   });
   }
   
  });
});