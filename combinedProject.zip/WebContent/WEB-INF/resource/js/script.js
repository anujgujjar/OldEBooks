function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
       
        console.log("Image URL: " + profile.getImageUrl());
        console.log("Email: " + profile.getEmail());
        var image=profile.getImageUrl();
        var email=profile.getEmail();
        $("#image").attr("src",image);
        $("#email").text(email);  
        $(".g-signin2").css("display","true");
        
}
